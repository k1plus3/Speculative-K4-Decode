# Kryptos K4: Speculative Decryption

This repository presents a structured, multilingual, and cipher-informed attempt to unravel the final 97-character passage (K4) of the Kryptos sculpture by Jim Sanborn, located at CIA headquarters.

### Summary
This analysis began with the decoding of known plaintext fragments:
- **EAST**, **NORTHEAST**, **BERLIN**, **CLOCK** — confirmed by the artist
- **FOLK**, **FIX** — found via aligned Caesar shifts
- Spanish code words: **TIEMPO**, **CLAVE**, **MENSAJE**, **AGENTE**, **RELOJ**

### Cipher Techniques Used
- Vigenère cipher testing with known shift alignments
- Time-based ciphers inspired by the Berlin Clock
- Multilingual pattern detection (Spanish + English)
- Caesar shift matrix mapping to identify key patterns

### Final Message (Speculative)
> FOLK FIX CLOCK  
> BERLIN CLOCK IS THE KEY  
> THE MESSAGE IS HIDDEN IN TIME  
> EAST NORTHEAST DIRECTION REVEALS THE CODE  
> ONLY THE AGENT KNOWS THE TRUTH

### Intent
This is a speculative release for research and open analysis. It does not claim to solve Kryptos K4, but presents a credible, symbolic reconstruction.
